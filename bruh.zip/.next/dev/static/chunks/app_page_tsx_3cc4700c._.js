(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e87a1106._.js",
  "static/chunks/components_05c0e2f9._.js"
],
    source: "dynamic"
});
